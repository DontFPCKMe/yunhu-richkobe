package com.juhao.murexide.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.juhao.murexide.ui.theme.UiState

@Composable
fun Avatar(
    modifier: Modifier = Modifier,
    url: String,
    size: Dp = 48.dp,
    canView: Boolean = false,
    alwaysCircle: Boolean = false,
) {
    val context = LocalContext.current
    val squareAvatar by UiState.squareAvatar
    
    val shape = remember(squareAvatar) {
        if (squareAvatar && !alwaysCircle) {
            RoundedCornerShape(size / 4)
        } else {
            CircleShape
        }
    }
    val imageRequest = remember(url) {
        ImageRequest.Builder(context)
            .data(url)
            .apply {
                if (url.contains("chat-img.jwznb.com") ||
                    url.contains("jwznb.com") ||
                    url.contains("myapp.jwznb.com")
                ) {
                    setHeader("Referer", "https://myapp.jwznb.com")
                }
            }
            .build()
    }

    AsyncImage(
        model = imageRequest,
        contentDescription = null,
        modifier = modifier
            .size(size)
            .clip(shape)
            .then(
                if (canView)
                    Modifier.clickable {
                        showImageViewer(
                            context = context,
                            images = listOf(fullImagePreviewItem(url))
                        )
                    }
                else Modifier
            ),
        contentScale = ContentScale.Crop
    )
}
